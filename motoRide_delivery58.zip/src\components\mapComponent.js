import { icon } from '../utils/icons.js';
import { fareCalculator } from '../services/fareCalculator.js';
import { showToast } from './toast.js';

export class MapComponent {
  constructor(containerId, options = {}) {
    this.targetElement = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    this.options = {
      center: [10.6427, -71.6125], // Maracaibo default
      zoom: 14,
      darkMode: true,
      is3D: false, // Standard 2D flat mode
      ...options
    };
    
    this.markers = new Map();
    this.routeLayer = null;
    this.userMarker = null;
    this.pickupMarker = null;
    this.destinationMarker = null;
    this.is3DActive = false;
    
    this._initMap();
    this._createLocationButton();
  }

  _initMap() {
    if (!this.targetElement) return;
    try {
      this.map = L.map(this.targetElement, { zoomControl: false }).setView(this.options.center, this.options.zoom);
      
      const tileUrl = this.options.darkMode 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
        
      L.tileLayer(tileUrl, {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 20
      }).addTo(this.map);
    } catch (err) {
      console.error('[MapComponent] Map init error:', err);
    }
  }

  _createLocationButton() {
    if (!this.targetElement) return;

    this.locateBtn = document.createElement('button');
    this.locateBtn.className = 'gps-locate-btn';
    this.locateBtn.title = 'Ir a mi ubicación actual';
    this.locateBtn.innerHTML = `🎯`;
    Object.assign(this.locateBtn.style, {
      position: 'absolute',
      bottom: '100px',
      right: '16px',
      zIndex: '99',
      width: '48px',
      height: '48px',
      borderRadius: '50%',
      backgroundColor: 'rgba(24, 34, 50, 0.92)',
      backdropFilter: 'blur(16px)',
      border: '1.5px solid var(--accent-primary)',
      color: '#FFC107',
      fontSize: '1.3rem',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 8px 20px rgba(0,0,0,0.5), 0 0 15px rgba(255,193,7,0.25)',
      transition: 'all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
    });

    this.locateBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      this.locateBtn.style.transform = 'scale(0.85)';
      setTimeout(() => this.locateBtn.style.transform = 'scale(1)', 150);

      const loc = await this.getUserLocation();
      this.centerOn(loc.lat, loc.lng, 15);
      this.setUserLocation(loc.lat, loc.lng);
      showToast('🎯 Ubicación centrada en tu GPS', 'info');
    });

    if (getComputedStyle(this.targetElement).position === 'static') {
      this.targetElement.style.position = 'relative';
    }
    this.targetElement.appendChild(this.locateBtn);
  }

  toggle3DMode() {
    // 2D flat mode locked
  }

  onMapClick(callback) {
    if (!this.map) return;
    this.map.on('click', (e) => {
      if (typeof callback === 'function') {
        callback(e.latlng);
      }
    });
  }

  init(center = { lat: 10.6427, lng: -71.6125 }, zoom = 14) {
    if (this.map) {
      const c = Array.isArray(center) ? center : [center.lat, center.lng];
      this.map.setView(c, zoom);
    }
  }

  initMap(lat = 10.6427, lng = -71.6125, zoom = 14) {
    if (this.map) {
      this.map.setView([lat, lng], zoom);
    }
  }

  setUserLocation(lat, lng) {
    if (!this.map) return;
    if (this.userMarker) {
      this.userMarker.setLatLng([lat, lng]);
      return;
    }
    
    const userIcon = L.divIcon({
      className: 'user-location-marker',
      html: `<div style="width: 24px; height: 24px; background-color: var(--accent-secondary, #00D2FF); border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px rgba(0,210,255,0.8); animation: pulse 2s infinite;"></div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });
    
    this.userMarker = L.marker([lat, lng], { icon: userIcon }).addTo(this.map);
  }

  setDriverLocation(lat, lng) {
    this.setUserLocation(lat, lng);
  }

  addDriverMarker(id, lat, lng, heading = 0, info = {}) {
    if (!this.map) return null;
    
    const svgIcon = L.divIcon({
      className: 'driver-3d-marker',
      html: `
        <div class="moto-3d-badge">
          <div class="moto-3d-shadow"></div>
          <div class="moto-3d-body" style="transform: rotate(${heading}deg);">
            <svg class="moto-3d-arrow" viewBox="0 0 24 24">
              <path d="M12 2L19 21L12 17L5 21L12 2Z"/>
            </svg>
          </div>
        </div>
      `,
      iconSize: [44, 44],
      iconAnchor: [22, 22]
    });
    
    const marker = L.marker([lat, lng], { icon: svgIcon }).addTo(this.map);
    this.markers.set(id, marker);
    return marker;
  }

  addMarker(latlng, type = 'driver', options = {}) {
    if (!this.map) return;
    const coords = Array.isArray(latlng) ? latlng : [latlng.lat, latlng.lng];
    if (type === 'destination') {
      this.setDestinationMarker(coords[0], coords[1]);
    } else if (type === 'pickup') {
      this.setPickupMarker(coords[0], coords[1]);
    } else {
      const id = 'marker_' + Math.random();
      this.addDriverMarker(id, coords[0], coords[1], Math.floor(Math.random() * 360));
    }
  }

  clearMarkers(type = null) {
    if (!this.map) return;
    if (type === 'destination' && this.destinationMarker) {
      this.map.removeLayer(this.destinationMarker);
      this.destinationMarker = null;
    } else if (type === 'pickup' && this.pickupMarker) {
      this.map.removeLayer(this.pickupMarker);
      this.pickupMarker = null;
    } else {
      this.markers.forEach(marker => this.map.removeLayer(marker));
      this.markers.clear();
    }
  }

  updateDriverMarker(id, lat, lng, heading = 0) {
    const marker = this.markers.get(id);
    if (!marker) return;

    const bodyEl = marker.getElement()?.querySelector('.moto-3d-body');
    if (bodyEl) {
      bodyEl.style.transform = `rotate(${heading}deg)`;
    }

    this._animateMarker(marker, [lat, lng], 1500);
  }

  _animateMarker(marker, newLatLng, duration = 1500) {
    const start = marker.getLatLng();
    const startTime = performance.now();
    
    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const lat = start.lat + (newLatLng[0] - start.lat) * progress;
      const lng = start.lng + (newLatLng[1] - start.lng) * progress;
      
      marker.setLatLng([lat, lng]);
      
      if (progress < 1) requestAnimationFrame(animate);
    };
    
    requestAnimationFrame(animate);
  }

  removeDriverMarker(id) {
    const marker = this.markers.get(id);
    if (marker) {
      this.map.removeLayer(marker);
      this.markers.delete(id);
    }
  }

  setPickupMarker(lat, lng) {
    if (!this.map) return;
    if (this.pickupMarker) {
      this.pickupMarker.setLatLng([lat, lng]);
      return;
    }
    
    const pickupIcon = L.divIcon({
      className: 'pickup-beacon-marker',
      html: `
        <div class="beacon-3d-container">
          <div class="beacon-head"></div>
          <div class="beacon-pillar"></div>
        </div>
      `,
      iconSize: [24, 64],
      iconAnchor: [12, 64]
    });
    
    this.pickupMarker = L.marker([lat, lng], { icon: pickupIcon }).addTo(this.map);
  }

  setDestinationMarker(lat, lng) {
    if (!this.map) return;
    if (this.destinationMarker) {
      this.destinationMarker.setLatLng([lat, lng]);
      return;
    }
    
    const destIcon = L.divIcon({
      className: 'destination-flag-marker',
      html: `
        <div class="flag-3d-container">
          <div class="flag-head">🚩</div>
          <div class="beacon-pillar" style="background: linear-gradient(to top, rgba(255,77,77,0.8), rgba(255,77,77,0)); box-shadow: 0 0 15px var(--danger);"></div>
        </div>
      `,
      iconSize: [28, 68],
      iconAnchor: [14, 68]
    });
    
    this.destinationMarker = L.marker([lat, lng], { icon: destIcon }).addTo(this.map);
  }

  async drawRoute(start, end, color = 'var(--accent-secondary, #00D2FF)') {
    this.clearRoute();
    if (!this.map) return { distance: 3000, duration: 300 };

    const pickupLat = Array.isArray(start) ? start[0] : start.lat;
    const pickupLng = Array.isArray(start) ? start[1] : start.lng;
    const destLat = Array.isArray(end) ? end[0] : end.lat;
    const destLng = Array.isArray(end) ? end[1] : end.lng;

    try {
      const routeInfo = await fareCalculator.calculateRoute(pickupLat, pickupLng, destLat, destLng);
      if (routeInfo && routeInfo.geometry && routeInfo.geometry.coordinates) {
        const latlngs = routeInfo.geometry.coordinates.map(c => [c[1], c[0]]);
        this.routeLayer = L.polyline(latlngs, {
          color: color,
          weight: 6,
          opacity: 0.9,
          dashArray: '12, 12',
          lineCap: 'round'
        }).addTo(this.map);

        this.fitBounds();
        return routeInfo;
      }
    } catch (e) {
      console.warn('[MapComponent] Route calculation fallback:', e);
    }

    const fallbackCoords = [[pickupLat, pickupLng], [destLat, destLng]];
    this.routeLayer = L.polyline(fallbackCoords, {
      color: color,
      weight: 6,
      opacity: 0.9,
      dashArray: '12, 12'
    }).addTo(this.map);
    
    return { distance: 3500, duration: 420 };
  }

  clearRoute() {
    if (this.routeLayer && this.map) {
      this.map.removeLayer(this.routeLayer);
      this.routeLayer = null;
    }
  }

  fitBounds() {
    if (!this.map) return;
    const latlngs = [];
    if (this.userMarker) latlngs.push(this.userMarker.getLatLng());
    if (this.pickupMarker) latlngs.push(this.pickupMarker.getLatLng());
    if (this.destinationMarker) latlngs.push(this.destinationMarker.getLatLng());
    if (this.routeLayer) latlngs.push(...this.routeLayer.getLatLngs());
    
    if (latlngs.length > 0) {
      this.map.fitBounds(L.latLngBounds(latlngs), { padding: [50, 50] });
    }
  }

  centerOn(lat, lng, zoom = null) {
    if (this.map) {
      this.map.setView([lat, lng], zoom || this.map.getZoom(), { animate: true });
    }
  }

  getUserLocation() {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve({ lat: 10.4806, lng: -66.9036 });
        return;
      }
      
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => resolve({ lat: 10.4806, lng: -66.9036 }),
        { enableHighAccuracy: true, timeout: 5000 }
      );
    });
  }

  destroy() {
    if (this.map) {
      this.map.remove();
      this.map = null;
    }
  }
}
